package com.jefenoche.entity;

import java.util.EnumSet;
import javax.annotation.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.WallClimberNavigation;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * El Jefe: criatura de piel pálida con traje azul y camisa blanca.
 * - Solo aparece de noche y desaparece al amanecer.
 * - Te acecha desde lejos y se queda quieto si lo miras.
 * - Si te ve de cerca te persigue, corre y trepa paredes.
 * - Recuerda dónde te vio por última vez y va a buscarte, y abre puertas.
 */
public class JefeEntity extends Monster {

    private static final EntityDataAccessor<Boolean> DATA_CLIMBING =
            SynchedEntityData.defineId(JefeEntity.class, EntityDataSerializers.BOOLEAN);

    /** Distancia a la que "te ve" y empieza a perseguirte. */
    private static final double SPOT_RANGE = 18.0D;

    @Nullable
    private Vec3 lastSeen;
    private int searchTicks;

    public JefeEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 20;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.34D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.5D);
    }

    /** Solo de noche, a oscuras y sin otro Jefe cerca. */
    public static boolean checkSpawn(EntityType<JefeEntity> type, ServerLevelAccessor level,
                                     MobSpawnType reason, BlockPos pos, RandomSource random) {
        if (!Monster.checkMonsterSpawnRules(type, level, reason, pos, random)) {
            return false;
        }
        if (reason == MobSpawnType.SPAWNER || reason == MobSpawnType.SPAWN_EGG
                || reason == MobSpawnType.COMMAND) {
            return true;
        }
        return !level.getLevel().isDay()
                && level.getEntitiesOfClass(JefeEntity.class, new AABB(pos).inflate(128.0D)).isEmpty();
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        return new WallClimberNavigation(this, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_CLIMBING, false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new OpenDoorGoal(this, false));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.3D, false));
        this.goalSelector.addGoal(3, new StalkGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new SpotPlayerGoal(this));
    }

    @Override
    public void setTarget(@Nullable LivingEntity target) {
        boolean first = target != null && this.getTarget() == null;
        super.setTarget(target);
        if (first && !this.level().isClientSide) {
            this.level().playSound(null, target.blockPosition(), SoundEvents.ENDERMAN_STARE,
                    SoundSource.HOSTILE, 1.0F, 0.6F);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            this.entityData.set(DATA_CLIMBING, this.horizontalCollision);

            LivingEntity target = this.getTarget();
            if (target != null && target.isAlive()) {
                if (this.hasLineOfSight(target)) {
                    this.lastSeen = target.position();
                    this.searchTicks = 200;
                }
            } else if (this.searchTicks > 0) {
                this.searchTicks--;
            }
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        // Desaparece al amanecer si no está persiguiendo a nadie.
        if (!this.level().isClientSide && this.level().isDay() && this.getTarget() == null
                && this.tickCount % 100 == 0 && !this.isPersistenceRequired()) {
            this.discard();
        }
    }

    @Override
    public boolean onClimbable() {
        return this.entityData.get(DATA_CLIMBING);
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.ZOMBIE_STEP, 0.15F, 1.0F);
    }

    // ---------------------------------------------------------------- IA

    /** Te detecta (con línea de visión) solo dentro de SPOT_RANGE. */
    private static class SpotPlayerGoal extends NearestAttackableTargetGoal<Player> {
        SpotPlayerGoal(JefeEntity mob) {
            super(mob, Player.class, true);
        }

        @Override
        public boolean canUse() {
            return super.canUse() && this.target != null
                    && this.mob.distanceToSqr(this.target) < SPOT_RANGE * SPOT_RANGE;
        }
    }

    /**
     * Acecho: si hay un jugador cerca pero aún no te "vio", se acerca despacio
     * y se congela si lo estás mirando. Tras perderte, va a la última posición conocida.
     */
    private static class StalkGoal extends Goal {
        private final JefeEntity mob;
        @Nullable
        private Player prey;
        private int repath;

        StalkGoal(JefeEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (this.mob.getTarget() != null) {
                return false;
            }
            if (this.mob.lastSeen != null && this.mob.searchTicks > 0) {
                return true;
            }
            this.prey = this.findPrey();
            return this.prey != null && this.mob.distanceTo(this.prey) > 8.0F;
        }

        @Override
        public boolean canContinueToUse() {
            return this.mob.getTarget() == null && this.canUse();
        }

        @Nullable
        private Player findPrey() {
            return this.mob.level().getNearestPlayer(this.mob.getX(), this.mob.getY(), this.mob.getZ(),
                    40.0D, EntitySelector.NO_CREATIVE_OR_SPECTATOR);
        }

        @Override
        public void stop() {
            this.prey = null;
            this.mob.getNavigation().stop();
        }

        @Override
        public void tick() {
            Vec3 seen = this.mob.lastSeen;
            if (seen != null && this.mob.searchTicks > 0) {
                this.mob.getNavigation().moveTo(seen.x, seen.y, seen.z, 1.15D);
                if (this.mob.distanceToSqr(seen) < 4.0D) {
                    this.mob.lastSeen = null;
                    this.mob.searchTicks = 0;
                }
                return;
            }
            if (this.prey == null) {
                return;
            }
            this.mob.getLookControl().setLookAt(this.prey, 30.0F, 30.0F);
            if (isBeingWatched(this.prey)) {
                this.mob.getNavigation().stop();
            } else if (--this.repath <= 0) {
                this.repath = 10;
                this.mob.getNavigation().moveTo(this.prey, 0.9D);
            }
        }

        private boolean isBeingWatched(Player player) {
            Vec3 view = player.getViewVector(1.0F).normalize();
            Vec3 toMob = new Vec3(this.mob.getX() - player.getX(),
                    this.mob.getEyeY() - player.getEyeY(),
                    this.mob.getZ() - player.getZ()).normalize();
            return view.dot(toMob) > 0.93D && player.hasLineOfSight(this.mob);
        }
    }
}
