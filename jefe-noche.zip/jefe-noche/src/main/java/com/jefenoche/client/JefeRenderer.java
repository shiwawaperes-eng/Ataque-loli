package com.jefenoche.client;

import com.jefenoche.JefeNoche;
import com.jefenoche.entity.JefeEntity;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class JefeRenderer extends HumanoidMobRenderer<JefeEntity, JefeModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(JefeNoche.MODID, "textures/entity/jefe.png");

    public JefeRenderer(EntityRendererProvider.Context context) {
        super(context, new JefeModel(context.bakeLayer(ModelLayers.ZOMBIE)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(JefeEntity entity) {
        return TEXTURE;
    }
}
