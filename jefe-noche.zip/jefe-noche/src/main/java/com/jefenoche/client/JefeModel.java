package com.jefenoche.client;

import com.jefenoche.entity.JefeEntity;
import net.minecraft.client.model.AnimationUtils;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;

/** Modelo humanoide; levanta los brazos al perseguir (como un zombi). */
public class JefeModel extends HumanoidModel<JefeEntity> {

    public JefeModel(ModelPart root) {
        super(root);
    }

    @Override
    public void setupAnim(JefeEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        AnimationUtils.animateZombieArms(this.leftArm, this.rightArm, entity.isAggressive(),
                this.attackTime, ageInTicks);
    }
}
