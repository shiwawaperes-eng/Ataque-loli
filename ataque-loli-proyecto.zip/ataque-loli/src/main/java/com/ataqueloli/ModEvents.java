package com.ataqueloli;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.client.event.EntityRenderersEvent;

public class ModEvents {

    @Mod.EventBusSubscriber(modid = AtaqueLoliMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class Common {
        @SubscribeEvent
        public static void onAttributes(EntityAttributeCreationEvent event) {
            event.put(AtaqueLoliMod.LOLI.get(), LoliEntity.createAttributes().build());
        }
    }

    @Mod.EventBusSubscriber(modid = AtaqueLoliMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class Client {
        @SubscribeEvent
        public static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(AtaqueLoliMod.LOLI.get(), LoliRenderer::new);
        }
    }
}
