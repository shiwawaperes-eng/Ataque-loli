package com.ataqueloli;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Hace aparecer a Ataque Loli cerca de cada jugador, solo de noche. */
@Mod.EventBusSubscriber(modid = AtaqueLoliMod.MODID)
public class NightSpawner {

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.level instanceof ServerLevel level)) {
            return;
        }
        if (level.dimension() != Level.OVERWORLD) {
            return;
        }
        // Cada 20 segundos, y solo de noche
        if (level.getGameTime() % 400 != 0 || !level.isNight()) {
            return;
        }

        for (ServerPlayer player : level.players()) {
            if (player.isSpectator() || player.isCreative()) {
                continue;
            }
            if (level.random.nextFloat() > 0.5F) {
                continue;
            }
            AABB area = player.getBoundingBox().inflate(80.0D);
            if (!level.getEntitiesOfClass(LoliEntity.class, area).isEmpty()) {
                continue; // ya hay una cerca
            }

            double angle = level.random.nextDouble() * Math.PI * 2.0D;
            double dist = 28.0D + level.random.nextDouble() * 10.0D;
            int x = (int) Math.floor(player.getX() + Math.cos(angle) * dist);
            int z = (int) Math.floor(player.getZ() + Math.sin(angle) * dist);
            if (!level.hasChunkAt(new BlockPos(x, 64, z))) {
                continue;
            }
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos pos = new BlockPos(x, y, z);
            if (!level.getFluidState(pos.below()).isEmpty()) {
                continue; // no aparecer sobre el agua
            }

            LoliEntity loli = AtaqueLoliMod.LOLI.get().create(level);
            if (loli == null) {
                continue;
            }
            loli.moveTo(x + 0.5D, y, z + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
            if (level.noCollision(loli)) {
                level.addFreshEntity(loli);
            }
        }
    }
}
