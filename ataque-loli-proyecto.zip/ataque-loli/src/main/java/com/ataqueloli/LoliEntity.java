package com.ataqueloli;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

/**
 * Ataque Loli: niña fantasma nocturna. Camina lento hasta que te ve;
 * entonces grita CORRE y te persigue a gran velocidad.
 */
public class LoliEntity extends Monster {
    private static final double CALM_SPEED = 0.20D;
    private static final double CHASE_SPEED = 0.42D;

    private int lastShoutTick = -1000;

    public LoliEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 10;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.MOVEMENT_SPEED, CALM_SPEED)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0D, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        // mustSee = true: solo te persigue cuando te VE
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void setTarget(@Nullable LivingEntity target) {
        super.setTarget(target);
        if (this.level().isClientSide) {
            return;
        }
        AttributeInstance speed = this.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed == null) {
            return;
        }
        if (target instanceof ServerPlayer player) {
            speed.setBaseValue(CHASE_SPEED);
            if (this.tickCount - this.lastShoutTick > 200) {
                this.lastShoutTick = this.tickCount;
                shout(player);
            }
        } else if (target == null) {
            speed.setBaseValue(CALM_SPEED);
        }
    }

    private void shout(ServerPlayer player) {
        player.connection.send(new ClientboundSetTitlesAnimationPacket(2, 30, 10));
        player.connection.send(new ClientboundSetTitleTextPacket(
                Component.literal("CORRE").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD)));
        player.sendSystemMessage(
                Component.literal("<Ataque Loli> CORRE").withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
        player.playNotifySound(SoundEvents.ENDERMAN_SCREAM, SoundSource.HOSTILE, 1.0F, 0.5F);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        // Con el amanecer se desvanece
        if (!this.level().isClientSide && this.tickCount > 100 && this.level().isDay()) {
            ((ServerLevel) this.level()).sendParticles(ParticleTypes.SMOKE,
                    this.getX(), this.getY() + 1.0D, this.getZ(), 15, 0.2D, 0.5D, 0.2D, 0.02D);
            this.discard();
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.VEX_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.VEX_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.VEX_DEATH;
    }
}
