package com.ataqueloli;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(AtaqueLoliMod.MODID)
public class AtaqueLoliMod {
    public static final String MODID = "ataqueloli";

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);

    public static final RegistryObject<EntityType<LoliEntity>> LOLI = ENTITIES.register("loli",
            () -> EntityType.Builder.of(LoliEntity::new, MobCategory.MONSTER)
                    .sized(0.5F, 1.4F)
                    .clientTrackingRange(10)
                    .build("loli"));

    public AtaqueLoliMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
    }
}
