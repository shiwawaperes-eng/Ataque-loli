package com.ataqueloli;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.AbstractZombieModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class LoliRenderer extends MobRenderer<LoliEntity, LoliRenderer.LoliModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(AtaqueLoliMod.MODID, "textures/entity/loli.png");

    public LoliRenderer(EntityRendererProvider.Context context) {
        super(context, new LoliModel(context.bakeLayer(ModelLayers.ZOMBIE)), 0.35F);
    }

    @Override
    protected void scale(LoliEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.75F, 0.75F, 0.75F); // tamaño de niña
    }

    @Override
    public ResourceLocation getTextureLocation(LoliEntity entity) {
        return TEXTURE;
    }

    /** Modelo humanoide con los brazos extendidos al perseguir. */
    public static class LoliModel extends AbstractZombieModel<LoliEntity> {
        public LoliModel(ModelPart part) {
            super(part);
        }

        @Override
        public boolean isAggressive(LoliEntity entity) {
            return entity.isAggressive();
        }
    }
}
